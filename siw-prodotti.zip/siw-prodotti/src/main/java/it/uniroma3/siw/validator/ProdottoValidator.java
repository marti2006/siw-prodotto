package it.uniroma3.siw.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.model.Prodotto;
import it.uniroma3.siw.repository.ProdottoRepository;

@Component
public class ProdottoValidator implements Validator {

	@Autowired
	public ProdottoRepository prodottoRepository;


	public void validate(Object o,Errors errors) {
		Prodotto p=(Prodotto)o;
		if(p.getId()==0) {
			if(p.getDescrizione()!=null && p.getNome()!=null &&p.getPrezzo()!=0.0f
					&& prodottoRepository.existsByNomeAndDescrizioneAndPrezzo(p.getNome(),p.getDescrizione(),p.getPrezzo())) {
				errors.reject("prodotto.duplicate");
			}
		}

	}

	public boolean supports(Class<?> aClass) {
		return Prodotto.class.equals(aClass);
	}

}


