package it.uniroma3.siw.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.model.Fornitore;
import it.uniroma3.siw.repository.FornitoreRepository;

@Component
public class FornitoreValidator implements Validator {

	@Autowired
	public FornitoreRepository fornitoreRepository;


	public void validate(Object o,Errors errors) {
		Fornitore p=(Fornitore)o;
		if(p.getId()==0) {
			if(p.getNome()!=null && p.getIndirizzo()!=null &&p.getEmail()!=null
					&& fornitoreRepository.existsByNomeAndIndirizzoAndEmail(p.getNome(),p.getIndirizzo(),p.getEmail())) {
				errors.reject("fornitore.duplicate");
			}
		}
	}

	public boolean supports(Class<?> aClass) {
		return Fornitore.class.equals(aClass);
	}

}


