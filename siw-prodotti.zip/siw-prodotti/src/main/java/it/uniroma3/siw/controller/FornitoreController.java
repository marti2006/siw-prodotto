package it.uniroma3.siw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import it.uniroma3.siw.model.Fornitore;
import it.uniroma3.siw.repository.FornitoreRepository;
import it.uniroma3.siw.validator.FornitoreValidator;
import jakarta.validation.Valid;

@Controller
public class FornitoreController {

	@Autowired FornitoreRepository fornitoreRepository;
	@Autowired FornitoreValidator fornitoreValidator;
	
	@GetMapping("/fornitori")
	public String tuttiFornitori(Model model) {
		model.addAttribute("fornitori", this.fornitoreRepository.findAll());
		return "fornitori.html";
	}
	
	@GetMapping("/admin/aggiungiNuovoFornitore")
	public String aggiungiNuovoFornitore(Model model) {
		model.addAttribute("fornitore", new Fornitore());
		return "aggiungiNuovoFornitore.html";
	}
	@GetMapping("/admin/modificaFornitore/{id}")
	public String modificaFornitore(@PathVariable("id")Long id,Model model) {
		model.addAttribute("fornitore", this.fornitoreRepository.findById(id).get());
		return "aggiungiNuovoFornitore.html";
	}
	
	
	@PostMapping("/admin/fornitore")
	public String nuovoFornitore(@Valid@ModelAttribute("prodotto") Fornitore fornitore,BindingResult bindingResult,
			Model model) {
		this.fornitoreValidator.validate(fornitore, bindingResult);
		if(!bindingResult.hasErrors()) {
			this.fornitoreRepository.save(fornitore);
			model.addAttribute("fornitore", fornitore);
			return "fornitore.html";			
		}
		else {
			return "aggiungiNuovoFornitore.html";
		}
	}
	
	@GetMapping("/fornitori/{id}")
	public String singoloFornitore(@PathVariable("id")Long id,Model model) {
		model.addAttribute("fornitore", this.fornitoreRepository.findById(id).get());
		return "fornitore.html";
	}
}
