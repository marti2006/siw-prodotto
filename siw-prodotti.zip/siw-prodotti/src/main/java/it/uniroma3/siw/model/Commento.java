package it.uniroma3.siw.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
public class Commento {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	@NotBlank
	private String testo;
	@ManyToOne
//	@NotBlank
	private Prodotto prodotto;
	@ManyToOne
	private User autore;
    @NotNull
    @Min(0)
    @Max(5)
	private Integer stelle;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTesto() {
		return testo;
	}
	public void setTesto(String testo) {
		this.testo = testo;
	}
	public Prodotto getProdotto() {
		return prodotto;
	}
	public void setProdotto(Prodotto prodotto) {
		this.prodotto = prodotto;
	}
	public User getAutore() {
		return autore;
	}
	public void setAutore(User autore) {
		this.autore = autore;
	}
	public Integer getStelle() {
		return stelle;
	}
	public void setStelle(Integer stelle) {
		this.stelle = stelle;
	}
	@Override
	public boolean equals(Object o) {
		Commento c=(Commento)o;
		if(c.getTesto().equals(this.getTesto()) && c.getProdotto().equals(this.getProdotto()) && c.getAutore().equals(this.getAutore()))
			return true;
		return false;
	}
	@Override
	public int hashCode() {
		return this.getTesto().hashCode()+this.getProdotto().hashCode()+this.getAutore().hashCode();
	}


}
