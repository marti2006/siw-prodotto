package it.uniroma3.siw.model;


public class CommentoHtml {
	
	public User getAutore() {
		return autore;
	}
	public void setAutore(User autore) {
		this.autore = autore;
	}
	private long id;
	private String testo;
	private long prodottoid;
	private Integer stelle;
	private User autore;

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTesto() {
		return testo;
	}
	public void setTesto(String testo) {
		this.testo = testo;
	}
	public long getProdottoid() {
		return prodottoid;
	}
	public void setProdottoid(long prodottoid) {
		this.prodottoid = prodottoid;
	}
	public Integer getStelle() {
		return stelle;
	}
	public void setStelle(Integer stelle) {
		this.stelle = stelle;
	}
	
}
