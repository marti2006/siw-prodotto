package it.uniroma3.siw.validator;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.model.Commento;
import it.uniroma3.siw.model.CommentoHtml;
import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Prodotto;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.repository.CommentoRepository;
import it.uniroma3.siw.repository.ProdottoRepository;
import it.uniroma3.siw.service.CredentialsService;

@Component
public class CommentoHtmlValidator implements Validator {

	@Autowired
	public CommentoRepository commentoRepository;
	@Autowired ProdottoRepository prodottoRepository;
	@Autowired CredentialsService credentialsService;

	public void validate(Object o,Errors errors) {
		CommentoHtml c=(CommentoHtml)o;
		long prodottoid=c.getProdottoid();
		Optional<Prodotto> p=this.prodottoRepository.findById(prodottoid);
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		
		if(c.getId()==0) {
			if(c.getTesto()!=null
					&& commentoRepository.existsByTestoAndProdottoAndAutore(c.getTesto(),p,credentials.getUser())) {
				errors.reject("commento.duplicate");
			}
			
		}
	}

	public boolean supports(Class<?> aClass) {
		return CommentoHtml.class.equals(aClass);
	}

}


