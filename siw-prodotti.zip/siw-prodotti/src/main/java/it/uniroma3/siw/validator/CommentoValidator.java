package it.uniroma3.siw.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.model.Commento;
import it.uniroma3.siw.repository.CommentoRepository;

@Component
public class CommentoValidator implements Validator {

	@Autowired
	public CommentoRepository commentoRepository;


	public void validate(Object o,Errors errors) {
		Commento c=(Commento)o;
		if(c.getTesto()!=null && c.getProdotto()!=null && c.getAutore()!=null
				&& commentoRepository.existsByTestoAndProdottoAndAutore(c.getTesto(),c.getProdotto(),c.getAutore())) {
			errors.reject("commento.duplicate");
		}

	}

	public boolean supports(Class<?> aClass) {
		return Commento.class.equals(aClass);
	}

}


