package it.uniroma3.siw.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.model.Commento;
import it.uniroma3.siw.model.Prodotto;
import it.uniroma3.siw.model.User;

public interface CommentoRepository extends CrudRepository<Commento, Long>{
	public boolean existsByTestoAndProdottoAndAutore(String testo,Optional<Prodotto> p,User autore);
	public List<Commento> findByAutore(User autore);
	public List<Commento> findByProdotto(Prodotto prodotto);
	public boolean existsByTestoAndProdottoAndAutore(String testo, Prodotto prodotto, User autore);


}
