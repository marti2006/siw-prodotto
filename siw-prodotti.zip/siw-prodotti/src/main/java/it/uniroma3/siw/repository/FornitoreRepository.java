package it.uniroma3.siw.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import it.uniroma3.siw.model.Fornitore;

public interface FornitoreRepository extends CrudRepository<Fornitore, Long>{

	public boolean existsByNomeAndIndirizzoAndEmail(String nome,String descr,String email);

	@Query(value="select * "
			+ "from fornitore a "
			+ "where a.id not in "
			+ "(select fornitori_id "
			+ "from prodotto_fornitori "
			+ "where prodotto_fornitori.prodotti_venduti_id = :prodottoId)", nativeQuery=true)
	public Iterable<Fornitore> findFornitoreNotInProdotto(@Param("prodottoId") Long id);

}
