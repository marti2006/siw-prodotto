package it.uniroma3.siw.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import it.uniroma3.siw.model.Commento;
import it.uniroma3.siw.model.CommentoHtml;
import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Fornitore;
import it.uniroma3.siw.model.Prodotto;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.repository.CommentoRepository;
import it.uniroma3.siw.repository.CredentialsRepository;
import it.uniroma3.siw.repository.FornitoreRepository;
import it.uniroma3.siw.repository.ProdottoRepository;
import it.uniroma3.siw.repository.UserRepository;
import it.uniroma3.siw.service.CredentialsService;
import it.uniroma3.siw.validator.CommentoHtmlValidator;
import it.uniroma3.siw.validator.CommentoValidator;
import it.uniroma3.siw.validator.ProdottoValidator;
import jakarta.validation.Valid;

@Controller
public class ProdottoController {

	@Autowired ProdottoRepository prodottoRepository;
	@Autowired ProdottoValidator prodottoValidator;
	@Autowired FornitoreRepository fornitoreRepository;
	@Autowired CommentoRepository commentoRepository;
	@Autowired CommentoValidator commentoValidator;
	@Autowired CommentoHtmlValidator commentohtmlValidator;
	@Autowired CredentialsRepository credentialsRepository;
	@Autowired CredentialsService credentialsService;
	
	
	
	@GetMapping("/index")
	public String index() {
		return "index.html";
	}
	@GetMapping("/prodotti")
	public String tuttiProdotti(Model model) {
		model.addAttribute("prodotti", this.prodottoRepository.findAll());
		return "prodotti.html";
	}
	
	@GetMapping("/admin/aggiungiNuovoProdotto")
	public String aggiungiNuovoProdotto(Model model) {
		model.addAttribute("fornitori",this.fornitoreRepository.findAll());
		model.addAttribute("prodotto", new Prodotto());
		return "aggiungiNuovoProdotto.html";
	}
	@GetMapping("/admin/modificaProdotto/{id}")
	public String modificaProdotto(@PathVariable("id")Long id,Model model) {
		model.addAttribute("fornitori",this.fornitoreRepository.findAll());		
		model.addAttribute("prodotto", this.prodottoRepository.findById(id).get());
		return "aggiungiNuovoProdotto.html";
	}
	
	
	@PostMapping("/admin/prodotto")
	public String nuovoProdotto(@Valid@ModelAttribute("prodotto") Prodotto prodotto,BindingResult bindingResult,
			Model model) {
		this.prodottoValidator.validate(prodotto, bindingResult);
		if(!bindingResult.hasErrors()) {
			this.prodottoRepository.save(prodotto);
			model.addAttribute("prodotto", prodotto);
			return "prodotto.html";			
		}
		else {
			model.addAttribute("fornitori",this.fornitoreRepository.findAll());			
			return "aggiungiNuovoProdotto.html";
		}
	}
	
	@GetMapping("/prodotti/{id}")
	public String singoloProdotto(@PathVariable("id")Long id,Model model) {
		model.addAttribute("prodotto", this.prodottoRepository.findById(id).get());
		return "prodotto.html";
	}
	
	@GetMapping("/admin/cancellaProdotto/{id}")
	public String cancellaProdotto(@PathVariable("id")Long id,Model model) {
		model.addAttribute("prodotto", this.prodottoRepository.findById(id).get());
		this.prodottoRepository.delete(this.prodottoRepository.findById(id).get());
		return "prodottoEliminato.html";
	}
	
	@GetMapping("/admin/modificaFornitoriProdotto/{id}")
	public String modificaFornitori(@PathVariable("id") Long id, Model model) {

		List<Fornitore> fornitoriDaAggiungere = this.fornitoriDaAggiungere(id);
		model.addAttribute("fornitori", fornitoriDaAggiungere);
		model.addAttribute("prodotto", this.prodottoRepository.findById(id).get());

		return "fornitoriDaAggiungere.html";
	}
	
	@GetMapping(value="/admin/aggiungiFornitoreAProdotto/{fornitoreId}/{prodottoId}")
	public String aggiungiFornitoreAProdotto(@PathVariable("fornitoreId") Long fornitoreId, @PathVariable("prodottoId") Long prodottoId, Model model) {
		Prodotto prodotto = this.prodottoRepository.findById(prodottoId).get();
		Fornitore fornitore = this.fornitoreRepository.findById(fornitoreId).get();
		List<Fornitore> fornitori = prodotto.getFornitori();
		fornitori.add(fornitore);
		this.prodottoRepository.save(prodotto);
		
		List<Fornitore> fornitoriDaAggiungere = fornitoriDaAggiungere(prodottoId);
		
		model.addAttribute("prodotto", prodotto);
		model.addAttribute("fornitori", fornitoriDaAggiungere);

		return "fornitoriDaAggiungere.html";
	}
	
	@GetMapping(value="/admin/rimuoviFornitoreAProdotto/{fornitoreId}/{prodottoId}")
	public String rimuoviFornitoreAProdotto(@PathVariable("fornitoreId") Long fornitoreId, @PathVariable("prodottoId") Long prodottoId, Model model) {
		Prodotto prodotto = this.prodottoRepository.findById(prodottoId).get();
		Fornitore fornitore = this.fornitoreRepository.findById(fornitoreId).get();
		List<Fornitore> fornitori = prodotto.getFornitori();
		fornitori.remove(fornitore);
		this.prodottoRepository.save(prodotto);
		
		List<Fornitore> fornitoriDaAggiungere = fornitoriDaAggiungere(prodottoId);
		
		model.addAttribute("prodotto", prodotto);
		model.addAttribute("fornitori", fornitoriDaAggiungere);

		return "fornitoriDaAggiungere.html";
	}

	private List<Fornitore> fornitoriDaAggiungere(Long prodottoId) {
		List<Fornitore> fornitoriDaAggiungere = new ArrayList<>();

		for (Fornitore f : fornitoreRepository.findFornitoreNotInProdotto(prodottoId)) {
			fornitoriDaAggiungere.add(f);
		}
		return fornitoriDaAggiungere;
	}

	@GetMapping(value="/prodotti/{id}/commenti")
	public String tuttiCommentiProdotto(@PathVariable("id") Long id, Model model) {
		Prodotto p=this.prodottoRepository.findById(id).get();
		model.addAttribute("prodotto", p);			
		model.addAttribute("commenti", p.getCommenti());
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		model.addAttribute("autore", credentials.getUser());
		return "commentiProdotto.html";			
	}
	@GetMapping(value="/prodotti/{id}/aggiungiCommento")
	public String aggiungiCommento(@PathVariable("id") Long id, Model model) {
		CommentoHtml c=new CommentoHtml();
		Prodotto p=this.prodottoRepository.findById(id).get();
		c.setProdottoid(p.getId());
		model.addAttribute("commento", c);
		return "aggiungiNuovoCommento.html";
	}
	@GetMapping(value="/prodotti/{id}/modifica/{commentoid}")
	public String modificaCommento(@PathVariable("id") Long id,@PathVariable("commentoid") Long commentoid, Model model) {
		Optional<Commento> co=commentoRepository.findById(commentoid);
		CommentoHtml c=new CommentoHtml();
		c.setId(co.get().getId());
		c.setTesto(co.get().getTesto());
		c.setStelle(co.get().getStelle());
		c.setProdottoid(co.get().getProdotto().getId());
		model.addAttribute("commento", c);
		return "aggiungiNuovoCommento.html";
	}
	@PostMapping("/commento")
	public String nuovoCommento(@Valid@ModelAttribute("commento") CommentoHtml commento,BindingResult bindingResult,
			Model model) {
		this.commentohtmlValidator.validate(commento, bindingResult);
		if(!bindingResult.hasErrors()) {
			Commento commentonew=new Commento();
			if(commento.getId()!=0) {
				commentonew.setId(commento.getId());
			}
			commentonew.setTesto(commento.getTesto());
			commentonew.setStelle(commento.getStelle());
			Prodotto p=this.prodottoRepository.findById(commento.getProdottoid()).get();
			commentonew.setProdotto(p);
			UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
			commentonew.setAutore(credentials.getUser());
			this.commentoRepository.save(commentonew);
			model.addAttribute("prodotto", p);			
			model.addAttribute("commenti", p.getCommenti());
			model.addAttribute("autore", credentials.getUser());			
			return "commentiProdotto.html";			
		}
		else {
			
			//model.addAttribute("prodotto", commento.getProdotto());			
			return "aggiungiNuovoCommento.html";
		}
	}

}
