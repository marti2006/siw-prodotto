package it.uniroma3.siw.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@Entity
public class Fornitore {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	@NotBlank
	private String nome;
	@NotBlank
	private String indirizzo;
	@Email
	private String email;
	@ManyToMany(mappedBy="fornitori")
	private List<Prodotto>prodottiVenduti;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Prodotto> getProdottiVenduti() {
		return prodottiVenduti;
	}
	public void setProdottiVenduti(List<Prodotto> prodottiVenduti) {
		this.prodottiVenduti = prodottiVenduti;
	}
	@Override
	public boolean equals(Object o) {
		Fornitore f=(Fornitore)o;
		if(f!=null) {
			if(this.getNome().equals(f.getNome())&&this.getEmail().equals(f.getEmail())&&this.getIndirizzo().equals(f.getIndirizzo()))
				return true;
		}
		return false;
	}
	@Override
	public int hashCode() {
		return this.getNome().hashCode()+this.getEmail().hashCode()+this.getIndirizzo().hashCode();
	}
}
