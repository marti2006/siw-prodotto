package it.uniroma3.siw.model;

import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

@Entity
public class Prodotto {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	@NotBlank
	private String nome;
	@Positive
	private float prezzo;
	private String descrizione;
	@ManyToMany
	private List<Fornitore> fornitori=new ArrayList<>();
	@OneToMany(mappedBy="prodotto")
	private List<Commento> commenti;
	private Float punteggio;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public float getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(float prezzo) {
		this.prezzo = prezzo;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public List<Fornitore> getFornitori() {
		return fornitori;
	}
	public void setFornitori(List<Fornitore> fornitori) {
		this.fornitori = fornitori;
	}
	public List<Commento> getCommenti() {
		return commenti;
	}
	public void setCommenti(List<Commento> commenti) {
		this.commenti = commenti;
	}
	public Float getPunteggio() {
		return punteggio;
	}
	public void setPunteggio(Float punteggio) {
		this.punteggio = punteggio;
	}
	@Override
	public boolean equals(Object o) {
		Prodotto p=(Prodotto)o;
		if(p.getNome().equals(this.getNome())&&p.getDescrizione().equals(this.getDescrizione()) && p.getPrezzo()==this.getPrezzo()) {
//			if(p.getFornitori().equals(this.getFornitori())) {
				return true;				
//			}
		}
		return false;
	}
	@Override
	public int hashCode() {
		return (int) (this.getDescrizione().hashCode()+this.getNome().hashCode()+this.getPrezzo());
	}
}
